#. Acesse  Contabilidade > Relatórios > MIS > Relatórios MIS
#. Crie um novo Relatório
#. Selecione o plano de contas
#. Você pode optar por desabilitar a expansão das contas na aba layout para ter um relatório resumido.
#. Para selecionar os períodos, você pode:

    * Selecione diretamente o intervalo de datas desejado ou o nome do intervalo para obter o relatório apenas para esse período.
    * Clique em "Modo de comparação" e insira na guia "Colunas" quantas linhas forem diferentes períodos que deseja colocar. Esses períodos também podem ser definidos com datas fixas, ou colocar períodos relativos (por exemplo "Tipo de período" = "Ano", "Deslocamento" = "0" e "Duração" = "1" para o ano N, e o mesmo mas com “Deslocamento” = “-1” para o ano N - 1. Não se esqueça que a data base do relatório é no ano a ser analisado).

#. Clique em "Visualizar", "Imprimir" ou "Exportar" para calcular o relatório e executar a ação.
#. Se você estiver no modo de visualização, pode clicar no número nas linhas de detalhes para ver as notas relacionadas a esse número.
