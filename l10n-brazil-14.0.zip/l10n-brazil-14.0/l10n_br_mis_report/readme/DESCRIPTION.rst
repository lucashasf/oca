Templates de relatórios contábeis brasileiros: DRE e BP baseados no ITG 1000.

Balanço Patrimonial
-------------------

.. figure:: ../static/description/bp.png
   :alt: Balanço Patrimonial
   :width: 80 %
   :align: center

Demonstrativo de Resultados do Exercício (DRE)
----------------------------------------------

.. figure:: ../static/description/dre.png
   :alt: Demonstrativo de Resultados do Exercício (DRE)
   :width: 80 %
   :align: center
