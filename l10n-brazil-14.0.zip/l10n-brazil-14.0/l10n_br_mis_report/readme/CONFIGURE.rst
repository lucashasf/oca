Este relatório é estruturado a partir do tipo de conta, caso você esteja utilizando um plano de contas customizado
deverá ficar atendo a campo tipo de conta no cadastro do plano de contas.

Alem disso caso você esteja utilizando um dos plano de contas padrão e criar uma nova conta, você também deve ficar atendo a classificação.
