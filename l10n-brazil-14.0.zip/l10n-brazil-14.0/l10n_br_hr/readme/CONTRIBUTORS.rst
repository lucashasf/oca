* Rafael Lima
* Matheus Felix
* Luis Felipe Mileo <mileo@kmee.com.br>
* Daniel Sadamo Hirayama <daniel.sadamo@kmee.com.br>
* Bianca Bartolomei <bianca.bartolomei@kmee.com.br>
* Hendrix Costa
* Luis Felipe do Divino
* Luis Otávio Malta <luis.malta@kmee.com.br>
