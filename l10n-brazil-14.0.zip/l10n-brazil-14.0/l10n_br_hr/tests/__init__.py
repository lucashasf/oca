from . import test_l10n_br_hr
from . import test_hr_employee_dependent
