# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

from . import test_cnae
from . import test_service_type
from . import test_partner_profile
from . import test_certificate
from . import test_ibpt_product
from . import test_ibpt_service
from . import test_workflow
from . import test_fiscal_document_generic
from . import test_fiscal_closing
from . import test_subsequent_operation
from . import test_uom_uom
from . import test_fiscal_document_nfse
