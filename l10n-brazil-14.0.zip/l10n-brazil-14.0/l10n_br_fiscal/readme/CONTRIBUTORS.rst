* Renato Lima <renato.lima@akretion.com.br>
* Raphaël Valyi <raphael.valyi@akretion.com.br>
* Magno Costa <magno.costa@akretion.com.br>
* Luis Felipe Mileo <mileo@kmee.com.br>
* Marcel Savegnago <marcel.savegnago@escodoo.com.br>
* Luis Otavio Malta Conceição <luis.malta@kmee.com.br>
