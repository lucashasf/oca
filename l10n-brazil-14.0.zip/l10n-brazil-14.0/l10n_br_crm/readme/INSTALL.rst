Este módulo depende do módulo l10n_br_base e crm.
