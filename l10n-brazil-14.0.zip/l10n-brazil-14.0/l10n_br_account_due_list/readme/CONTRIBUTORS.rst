* `AKRETION <https://akretion.com/pt-BR/>`_:

  * Renato Lima <renato.lima@akretion.com.br>
  * Raphaël Valyi <raphael.valyi@akretion.com.br>

* Antonio Neto <netosjb@yahoo.com.br>
