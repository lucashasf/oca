In the invoice form view, there will be two tabs:

* Receivable in the case of customer invoices and payable in the case of supplier invoices:

  .. image:: ../static/img/l10n_br_account_due_list_receivable.png

* Payments with list of invoice payments:

  .. image:: ../static/img/l10n_br_account_due_list_payable.png
