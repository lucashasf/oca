This module creates the financial_move_line_ids field to list the payable or receivable account move line on invoices.
