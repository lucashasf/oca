Este módulo depende do pacote Python erpbrasil.base https://github.com/erpbrasil/erpbrasil.base
