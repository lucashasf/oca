# Copyright (C) 2015  Renato Lima - Akretion
# License AGPL-3 - See http://www.gnu.org/licenses/agpl-3.0.html

from . import format_address_mixin
from . import res_bank
from . import res_city
from . import res_country_state
from . import res_country
from . import party_mixin
from . import res_partner_bank
from . import res_partner
from . import state_tax_numbers
from . import res_company
from . import res_config_settings
