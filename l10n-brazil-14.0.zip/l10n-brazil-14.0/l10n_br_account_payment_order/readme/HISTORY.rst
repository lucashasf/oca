14.0.1.0.0 (2022-04-29)
~~~~~~~~~~~~~~~~~~~~~~~

* [MIG] Migração para a versão 14.0.

13.0.1.0.0 (2022-01-28)
~~~~~~~~~~~~~~~~~~~~~~~

* [MIG] Migração para a versão 13.0.

12.0.3.0.0 (2021-05-13)
~~~~~~~~~~~~~~~~~~~~~~~

* [MIG] Migração para a versão 12.0.
* Incluído a possibilidade de parametrizar o CNAB 240 e 400, devido a falta de padrão cada Banco e CNAB podem ter e usar codigos diferentes.
* Incluído os metodos para fazer alterações em CNAB já enviados.
* Incluído dados de demo e testes.
* Separado o objeto que fazia o Retorno do arquivo e registrava as informações para ter um objeto especifico que registra o Log e assim os modulos que implementam a biblioteca escolhida podem ter um metodo/objeto especifico para essa função.

12.0.1.0.0 (2019-06-06)
~~~~~~~~~~~~~~~~~~~~~~~

* [MIG] Inicio da Migração para a versão 12.0.

10.0.2.0.0 (2018-05-17)
~~~~~~~~~~~~~~~~~~~~~~~

* [REF] Modulo unido com o l10n_br_account_payment_mode e renomeado para l10n_br_account_payment_order.

10.0.1.0.0 (2018-08-29)
~~~~~~~~~~~~~~~~~~~~~~~

* [MIG] Migração para a versão 10.

8.0.1.0.1 (2017-07-14)
~~~~~~~~~~~~~~~~~~~~~~~

* [NEW] Refatoração e melhorias para suportar a geração de boletos através do br-cobranca (ruby)

8.0.1.0.0 (2017-07-14)
~~~~~~~~~~~~~~~~~~~~~~~

* [NEW] Melhorias para suportar a geração de pagamento da folha de pagamento;

8.0.0.0.0 (2016-01-18)
~~~~~~~~~~~~~~~~~~~~~~~

* [NEW] Primeira versão
