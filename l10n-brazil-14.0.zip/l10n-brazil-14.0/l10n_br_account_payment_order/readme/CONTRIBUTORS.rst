* `KMEE <https://www.kmee.com.br>`_:

  * Luis Felipe Mileo
  * Fernando Marcato
  * Hendrix Costa

* `Akretion <https://www.akretion.com/pt-BR>`_:

  * Magno Costa

* `Engenere <https://engenere.one>`_:

  * Antônio S. Pereira Neto

* `Escodoo <https://www.escodoo.com.br>`_:

  * Marcel Savegnago
