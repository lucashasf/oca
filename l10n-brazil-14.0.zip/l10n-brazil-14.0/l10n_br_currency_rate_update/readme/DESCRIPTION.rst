Este módulo implementa a consulta de cotação de moedas consultando o Banco
Central do Brasil. Ele estende o currency_rate_update do
repositório OCA/currency e adiciona o provedor BCB:

 * **Banco Central do Brasil** (portado por Renato Lima - Akretion):
   Implementa a consulta diária da cotação do moedas disponibilizada via
   API pelo banco central, para saber mais acesse o
   https://dadosabertos.bcb.gov.br/dataset/taxas-de-cambio-todos-os-boletins-diarios
